

def perim(r):
    return 4 / 3 * 3.149 * r * r * r


def area(r):
    return 4 * 3.14 * r * r
