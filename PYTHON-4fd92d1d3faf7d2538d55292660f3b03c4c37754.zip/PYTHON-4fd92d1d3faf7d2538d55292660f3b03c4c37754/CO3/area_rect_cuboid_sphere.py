
from graphics import rectangle as r
from graphics import circle as c
from graphics.threedgraphics import cuboid as cu
from graphics.threedgraphics import sphere as s

print(c.area(2))
print(c.peri(2))
print(r.area(2, 2))
print(r.perim(2, 2))
