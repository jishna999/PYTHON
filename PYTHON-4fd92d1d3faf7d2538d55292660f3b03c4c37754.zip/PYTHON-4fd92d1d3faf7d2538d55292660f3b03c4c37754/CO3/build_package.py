import math
print("3 to the power 2:", math.pow(3, 2))
print("square root of 64:", math.sqrt(64))