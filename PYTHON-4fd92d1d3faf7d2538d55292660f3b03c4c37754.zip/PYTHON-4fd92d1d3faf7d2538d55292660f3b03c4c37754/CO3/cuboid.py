def area(l, b, h):
    return 2 * (l + b + h)


def perim(l, b, h):
    return 4 * (l + b + h)