fact = 1
i = 1
n = int(input("enter the number:"))
while i <= n:
    fact = fact * i
    i = i + 1
print("factorial of", n, "is:", fact)