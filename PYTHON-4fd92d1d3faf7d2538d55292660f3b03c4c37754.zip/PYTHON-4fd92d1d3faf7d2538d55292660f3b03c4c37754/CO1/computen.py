n = int(input("enter a number:"))
s = str(n)
nn = s + s
nnn = s + s + s
temp = n + int(nn) + int(nnn)
print("the value of n+nn+nnn is:", temp)
