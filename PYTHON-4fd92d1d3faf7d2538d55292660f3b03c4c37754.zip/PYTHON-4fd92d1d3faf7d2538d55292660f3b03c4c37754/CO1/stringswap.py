a = input("enter first string:")
b = input("enter second string:")
s1 = b[0] + a[1:]
s2 = a[0] + b[1:]
print("the swapped string is:", s1 + '' + s2)
