a = input("enter a string:")
s = a[-1] + a[1:-1] + a[0]
print(s)
