import math

a = int(input("enter number1:"))
b = int(input("enter number2:"))
gcd = math.gcd(a, b)
print(gcd)
