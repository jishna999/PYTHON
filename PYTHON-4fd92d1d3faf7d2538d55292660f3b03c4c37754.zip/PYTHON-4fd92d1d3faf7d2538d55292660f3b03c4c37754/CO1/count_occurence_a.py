l = input("enter the names:")
print(l)
count = 0
for i in l:
    if i == "a":
        count += 1
print("the occurence of a is:", count)
