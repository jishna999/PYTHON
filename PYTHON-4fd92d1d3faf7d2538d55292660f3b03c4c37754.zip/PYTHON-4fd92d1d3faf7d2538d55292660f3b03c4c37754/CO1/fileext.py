file = input("enter a file name with extension:")
print("extension of the file is:", file.split(".")[-1])